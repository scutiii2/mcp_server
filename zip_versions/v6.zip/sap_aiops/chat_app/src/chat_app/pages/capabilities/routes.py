"""Live capability browser for the MCP server's tool catalog.

Nothing here is hardcoded - every request calls list_tools() on the MCP
server, so this page (and the try-it console on it) always reflects
whatever tools are actually registered right now, even if the MCP server
was redeployed five minutes ago with new tools added.

This blueprint owns everything under ``pages/capabilities/`` - both its
routes and its own ``template/`` folder. See ``pages/chat/routes.py`` and
``app.py`` for why the static/template wiring looks the way it does.
"""

from __future__ import annotations

from flask import Blueprint, jsonify, render_template, request

from chat_app.services.mcp_client import call_tool, list_tools
from chat_app.services.tool_titles import title_for


capabilities_bp = Blueprint(
    "capabilities",
    __name__,
    url_prefix="/capabilities",
    static_folder="template",
    static_url_path="/pages/capabilities/assets",
)


def _serialize_tools() -> list[dict]:
    """Reshape raw MCP Tool objects into plain dicts with a friendly
    title attached - shared by both the page and the JSON API so there's
    one place that knows this shape."""
    return [
        {
            "name": tool.name,
            "title": title_for(tool.name),
            "description": tool.description or "",
            "input_schema": tool.inputSchema or {},
        }
        for tool in list_tools()
    ]


@capabilities_bp.get("/")
def browse():
    try:
        tools = _serialize_tools()
        error = None
    except Exception as exc:  # noqa: BLE001 - surface any error to the page
        tools = []
        error = str(exc)
    return render_template("capabilities/index.html", tools=tools, error=error)


@capabilities_bp.get("/api/tools")
def api_tools():
    return jsonify(_serialize_tools())


@capabilities_bp.post("/api/try/<tool_name>")
def try_tool(tool_name: str):
    """Call a tool directly, bypassing chat/OpenAI entirely - for debugging."""
    arguments = request.get_json(force=True) or {}
    try:
        result = call_tool(tool_name, arguments)
        return jsonify({"status": "ok", "result": result})
    except Exception as exc:  # noqa: BLE001
        return jsonify({"status": "error", "message": str(exc)}), 500

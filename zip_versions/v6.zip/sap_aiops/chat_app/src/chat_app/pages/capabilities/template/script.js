async function runTool(event, toolName) {
  event.preventDefault();
  const form = event.target;
  const container = form.closest('.tool');
  const pre = container.querySelector('.result');
  const args = {};
  new FormData(form).forEach((value, key) => { if (value !== '') args[key] = value; });

  pre.style.display = 'block';
  pre.textContent = 'Running...';
  try {
    const res = await fetch(`/capabilities/api/try/${toolName}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(args),
    });
    const data = await res.json();
    pre.textContent = data.status === 'ok' ? data.result : `Error: ${data.message}`;
  } catch (err) {
    pre.textContent = `Request failed: ${err}`;
  }
  return false;
}

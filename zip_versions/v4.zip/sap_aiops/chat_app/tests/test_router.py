"""Router tests: the dispatch and availability logic that everything else
(the /api/providers route, the /api/chat route) relies on."""

from __future__ import annotations

from unittest.mock import patch

import pytest

from chat_app.services.llm import cooldown, router
from chat_app.services.llm.base import ChatResult


def test_list_providers_reflects_availability(monkeypatch):
    monkeypatch.setenv("OPENAI_API_KEY", "sk-test")
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)

    providers = {p["id"]: p for p in router.list_providers()}

    assert providers["openai"]["available"] is True
    assert providers["openai"]["label"] == "ChatGPT"
    assert providers["openai"]["reason"] is None
    assert providers["claude"]["available"] is False
    assert providers["claude"]["label"] == "Claude"
    assert providers["claude"]["reason"] == "missing_key"


def test_list_providers_reports_rate_limited_reason(monkeypatch):
    monkeypatch.setenv("OPENAI_API_KEY", "sk-test")
    cooldown.start_cooldown("openai", seconds=45)

    providers = {p["id"]: p for p in router.list_providers()}

    assert providers["openai"]["available"] is False
    assert providers["openai"]["reason"] == "rate_limited"
    assert 0 < providers["openai"]["cooldown_seconds_remaining"] <= 45


def test_run_chat_dispatches_to_requested_provider(monkeypatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-ant-test")
    expected = ChatResult(response="from claude", tools_used=[])

    with patch("chat_app.services.llm.claude_provider.run_chat", return_value=expected) as mock_run:
        result = router.run_chat("hello", [], "claude")

    assert result is expected
    mock_run.assert_called_once_with("hello", [])


def test_run_chat_defaults_to_openai_when_provider_not_specified(monkeypatch):
    monkeypatch.setenv("OPENAI_API_KEY", "sk-test")
    expected = ChatResult(response="from openai", tools_used=[])

    with patch("chat_app.services.llm.openai_provider.run_chat", return_value=expected) as mock_run:
        result = router.run_chat("hello", [], None)

    assert result is expected
    mock_run.assert_called_once_with("hello", [])


def test_run_chat_rejects_unavailable_provider(monkeypatch):
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)

    with pytest.raises(ValueError, match="Claude is not configured"):
        router.run_chat("hello", [], "claude")


def test_run_chat_rejects_unknown_provider():
    with pytest.raises(ValueError, match="Unknown provider"):
        router.run_chat("hello", [], "some-made-up-provider")


def test_run_chat_rejects_provider_in_cooldown_even_with_key(monkeypatch):
    monkeypatch.setenv("OPENAI_API_KEY", "sk-test")
    cooldown.start_cooldown("openai", seconds=30)

    with pytest.raises(ValueError, match="ChatGPT is rate-limited"):
        router.run_chat("hello", [], "openai")


def test_run_chat_cooldown_message_does_not_hide_missing_key(monkeypatch):
    """Missing key should win over 'not in cooldown' - there's nothing
    useful about telling someone to 'wait for the rate limit' when they
    never configured a key in the first place."""
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    cooldown.start_cooldown("claude", seconds=30)

    with pytest.raises(ValueError, match="Claude is not configured"):
        router.run_chat("hello", [], "claude")

"""OpenAI Responses API provider.

Owns its own tool-schema reshaping (``_tool_schemas``) rather than asking
``mcp_client`` for an OpenAI-flavored shape - each provider knows its own
wire format, ``mcp_client`` only knows the generic MCP one.
"""

from __future__ import annotations

import json
import os
from typing import Any

from openai import OpenAI

from chat_app.config import settings
from chat_app.services.llm.base import ChatResult, ProviderSpec
from chat_app.services.mcp_client import call_tool, list_tools


SYSTEM_PROMPT = (
    "You are a SAP Basis administrator assistant. Use tools to get real "
    "data - never guess. Confirm before any destructive action (stop/start "
    "a system, kernel update, rename)."
)

_client: OpenAI | None = None


def _get_client() -> OpenAI:
    global _client
    if _client is None:
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise ValueError("OPENAI_API_KEY not configured")
        _client = OpenAI(api_key=api_key)
    return _client


def is_available() -> bool:
    return bool(os.getenv("OPENAI_API_KEY"))


def _tool_schemas() -> list[dict[str, Any]]:
    return [
        {
            "type": "function",
            "name": tool.name,
            "description": tool.description or "",
            "parameters": tool.inputSchema or {"type": "object", "properties": {}},
        }
        for tool in list_tools()
    ]


def run_chat(question: str, history: list[dict[str, Any]]) -> ChatResult:
    client = _get_client()
    messages: list[Any] = [{"role": "system", "content": SYSTEM_PROMPT}, *history]
    messages.append({"role": "user", "content": question})
    tools_used: list[str] = []
    tool_schemas = _tool_schemas()

    for _ in range(6):
        response = client.responses.create(
            model=settings.openai_model,
            input=messages,
            tools=tool_schemas if tool_schemas else None,
        )
        function_calls = [item for item in response.output if getattr(item, "type", "") == "function_call"]
        if not function_calls:
            return ChatResult(response=response.output_text, tools_used=tools_used)

        messages.extend(response.output)
        for call in function_calls:
            try:
                arguments = json.loads(call.arguments or "{}")
            except Exception:
                arguments = {}
            tools_used.append(call.name)
            try:
                result_text = call_tool(call.name, arguments)
            except Exception as error:
                result_text = f"Tool '{call.name}' failed: {error}"
            messages.append({"type": "function_call_output", "call_id": call.call_id, "output": result_text})

    return ChatResult(response="Reached maximum tool-call rounds without a final answer.", tools_used=tools_used)


PROVIDER = ProviderSpec(id="openai", label="ChatGPT", is_available=is_available, run_chat=run_chat)

"""Provider registry and dispatch.

The only file that imports both provider modules. Routes never talk to
``openai_provider``/``claude_provider`` directly - only through here, so
adding a third provider later means touching this file and nothing else
on the routing side.
"""

from __future__ import annotations

from typing import Any

from chat_app.services.llm import claude_provider, openai_provider
from chat_app.services.llm.base import ChatResult, ProviderSpec


_PROVIDERS: dict[str, ProviderSpec] = {
    openai_provider.PROVIDER.id: openai_provider.PROVIDER,
    claude_provider.PROVIDER.id: claude_provider.PROVIDER,
}

DEFAULT_PROVIDER_ID = "openai"


def list_providers() -> list[dict[str, Any]]:
    """Live availability, not a static list - reflects whichever API keys
    are actually set right now."""
    return [
        {"id": provider.id, "label": provider.label, "available": provider.is_available()}
        for provider in _PROVIDERS.values()
    ]


def run_chat(question: str, history: list[dict[str, Any]], provider_id: str | None) -> ChatResult:
    provider_id = provider_id or DEFAULT_PROVIDER_ID
    provider = _PROVIDERS.get(provider_id)
    if provider is None:
        raise ValueError(f"Unknown provider '{provider_id}'")
    if not provider.is_available():
        raise ValueError(f"{provider.label} is not configured (missing API key)")
    return provider.run_chat(question, history)

"""MCP client wrapper - the only place this process talks to the MCP server.

Provider-agnostic on purpose: every LLM provider (openai_provider.py,
claude_provider.py, ...) reshapes this same live catalog into its own
wire format. This file only knows the generic MCP shape.
"""

from __future__ import annotations

import asyncio
from typing import Any

from mcp import ClientSession
from mcp.client.streamable_http import streamablehttp_client

from chat_app.config import settings


async def _list_tools_async() -> list[Any]:
    async with streamablehttp_client(settings.mcp_server_url) as (read, write, _):
        async with ClientSession(read, write) as session:
            await session.initialize()
            result = await session.list_tools()
            return result.tools


async def _call_tool_async(name: str, arguments: dict[str, Any]) -> str:
    async with streamablehttp_client(settings.mcp_server_url) as (read, write, _):
        async with ClientSession(read, write) as session:
            await session.initialize()
            result = await session.call_tool(name, arguments)
            parts = [getattr(block, "text", str(block)) for block in result.content]
            return "\n".join(parts) if parts else "(no output)"


def list_tools() -> list[Any]:
    """Live tool catalog from the MCP server - never a hardcoded list."""
    return asyncio.run(_list_tools_async())


def call_tool(name: str, arguments: dict[str, Any]) -> str:
    return asyncio.run(_call_tool_async(name, arguments))

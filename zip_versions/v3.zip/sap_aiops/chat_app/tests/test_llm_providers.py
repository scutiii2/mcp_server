"""Provider-level tests: schema reshaping and availability checks.

No real OpenAI/Anthropic calls happen here - ``run_chat`` itself (the part
that actually talks to the API) isn't exercised; that would require either
a live key or mocking the SDK client deeply enough that the test stops
proving much. What's genuinely worth testing without any of that is each
provider's tool-schema reshaping and its ``is_available()`` check, since
those are the pieces the rest of the app (the /capabilities-style
dropdown, the router) actually depends on.
"""

from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import patch

from chat_app.services.llm import claude_provider, openai_provider


def _fake_tool():
    return SimpleNamespace(
        name="stop_sap_system_tool",
        description="Stop a SAP system by SID.",
        inputSchema={"type": "object", "properties": {"sid": {"type": "string"}}},
    )


def test_openai_tool_schemas_use_function_parameters_shape():
    with patch("chat_app.services.llm.openai_provider.list_tools", return_value=[_fake_tool()]):
        schemas = openai_provider._tool_schemas()

    assert schemas == [
        {
            "type": "function",
            "name": "stop_sap_system_tool",
            "description": "Stop a SAP system by SID.",
            "parameters": {"type": "object", "properties": {"sid": {"type": "string"}}},
        }
    ]


def test_claude_tool_schemas_use_input_schema_shape():
    with patch("chat_app.services.llm.claude_provider.list_tools", return_value=[_fake_tool()]):
        schemas = claude_provider._tool_schemas()

    assert schemas == [
        {
            "name": "stop_sap_system_tool",
            "description": "Stop a SAP system by SID.",
            "input_schema": {"type": "object", "properties": {"sid": {"type": "string"}}},
        }
    ]


def test_openai_is_available_reflects_env_var(monkeypatch):
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    assert openai_provider.is_available() is False

    monkeypatch.setenv("OPENAI_API_KEY", "sk-test")
    assert openai_provider.is_available() is True


def test_claude_is_available_reflects_env_var(monkeypatch):
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    assert claude_provider.is_available() is False

    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-ant-test")
    assert claude_provider.is_available() is True

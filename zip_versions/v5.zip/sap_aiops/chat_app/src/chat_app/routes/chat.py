"""Chat page, provider list, and chat API."""

from __future__ import annotations

from flask import Blueprint, jsonify, render_template, request

from chat_app.services.llm import router


chat_bp = Blueprint("chat", __name__)


@chat_bp.get("/chat", strict_slashes=False)
def chat_page():
    return render_template("chat.html")


@chat_bp.get("/api/providers")
def providers_api():
    """Live availability - the frontend uses this to gray out any provider
    whose API key isn't configured, rather than letting the user pick it
    and only finding out it fails after sending a message."""
    return jsonify(router.list_providers())


@chat_bp.post("/api/chat")
def chat_api():
    data = request.get_json(force=True) or {}
    question = (data.get("question") or "").strip()
    if not question:
        return jsonify({"response": "Please enter a question."})
    try:
        result = router.run_chat(
            question,
            data.get("history", []),
            data.get("provider"),
            data.get("model"),
        )
        return jsonify({"response": result.response, "tools_used": result.tools_used, "provider_id": result.provider_id})
    except ValueError as error:
        return jsonify({"response": f"❌ {error}"})
    except Exception as error:
        return jsonify({"response": f"❌ Error: {error}"})
